# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['chatgpt_cli']

package_data = \
{'': ['*']}

install_requires = \
['openai>=0.27.0,<0.28.0', 'typer>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['chatgpt = chatgpt_cli.main:app']}

setup_kwargs = {
    'name': 'chatgpt-cli',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
